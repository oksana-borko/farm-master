package telran.dto;


public class ProductDto {

	String productName;
	int quantity;
	Double price;
	String imgUrl;
	FarmerDto farmer;
	
}
